shiboken_library_soversion = "6.11"

version = "6.11.1"
version_info = (6, 11, 1, "", "")

__build_date__ = '2026-05-11T05:50:39+00:00'




__setup_py_package_version__ = '6.11.1'

